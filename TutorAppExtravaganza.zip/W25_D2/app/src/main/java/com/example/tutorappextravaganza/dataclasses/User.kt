package com.example.tutorappextravaganza.dataclasses

import com.google.firebase.database.Exclude

open class User (
    @get: Exclude
    var id: String? = null,
    var lastName: String? = null,
    var firstName: String? = null,
    var email: String? = null,
    var role: String? = null,
    var teaches: Map<String, Course>? = null,
    // Courses the tutor teaches
    var availableTimeBlocks: MutableList<TimeBlock> = mutableListOf(),
    // User-defined availability slots
    var schedule: MutableList<Session> = mutableListOf(),
    // sessions that the tutor or student is involved in
    var tutorRating: MutableList<Int> = mutableListOf(),
    var tutorDocument: String? = null

) {

    // Optional helper to get a List of courses from the map
    fun getTeachesList(): List<Course> {
        return teaches?.values?.toList() ?: emptyList()
    }
}
/* notes: Kotlin doesn't seem to like inheritance with data classes, so not sure
* if we want to use this class for Tutor/Student/Admin objects. For now, will
* keep User class but won't use it */
