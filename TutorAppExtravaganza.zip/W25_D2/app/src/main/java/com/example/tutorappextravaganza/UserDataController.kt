package com.example.tutorappextravaganza
import android.content.Context
import com.example.tutorappextravaganza.dataclasses.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import android.util.Log
import android.widget.Toast

//NOTE: This file is being kept for future uses of the following firebase commands

object UserDataController {
    var auth = FirebaseAuth.getInstance()
    var database = FirebaseDatabase.getInstance().reference

    fun registerUser(
        email: String,
        password: String,
        lastName: String,
        firstName: String,
        role: String
    ){
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val userId = auth.currentUser?.uid
                    if (userId != null) {
                        Log.d("UserDataController", saveUserToDatabase(userId, lastName, firstName, email, role))
                    }
                } else {
                    Log.d("UserDataController","Registration Failed: ${task.exception?.message}")
                }
            }
    }


    private fun saveUserToDatabase(
        userId: String,
        lastName: String,
        firstName: String,
        email: String,
        role: String
    ): String {

        val user = User(userId, lastName, firstName, email) //could change to admin/tutor/student
        var message = ""

        database.child(role).child(userId).setValue(user) //change to tutor/student/admin
            .addOnSuccessListener{
                message = "Registration success!"
            }
            .addOnFailureListener {
                message = "Failed to register user in the database."
            }
        return message;
    }

    //NOTE: This function needs to be in an activity for the callback to change pages in a practical manner
   fun loginUser(email: String, password: String) {
       auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Log.d("UserDataController","Login Success!")
                    //startActivity(Intent(this, HomeActivity::class.java)) // Navigate to another activity
                } else {
                    Log.d("UserDataController","Login Failed: ${task.exception?.message}")
                }
            }
    }

    /*
        private fun getUserData(userId: String, role: String) {
            database.child(role).child(userId).get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot.exists()) {
                        val lastName = snapshot.child("lastName").value.toString()
                        val firstName = snapshot.child("firstName").value.toString()
                        val email = snapshot.child("email").value.toString()
                        Toast.makeText(this, "User: $firstName $lastName, Email: $email", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, "User Not Found", Toast.LENGTH_LONG).show()
                    }
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Failed to Retrieve Data: ${e.message}", Toast.LENGTH_LONG).show()
                }
        }

        private fun deleteUser(role: String = "Student") {
            val user = FirebaseAuth.getInstance().currentUser
            val database = FirebaseDatabase.getInstance().reference

            if (user != null) {
                val userId = user.uid

                // Step 1: Delete user data from the database
                database.child(role).child(userId).removeValue()
                    .addOnSuccessListener {
                        // Step 2: Delete user from Firebase Authentication
                        user.delete()
                            .addOnSuccessListener {
                                Toast.makeText(this, "User deleted successfully", Toast.LENGTH_SHORT).show()
                            }
                            .addOnFailureListener { e ->
                                Toast.makeText(this, "Failed to delete user: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(this, "Failed to remove user data: ${e.message}", Toast.LENGTH_LONG).show()
                    }
            } else {
                Toast.makeText(this, "No user is currently logged in", Toast.LENGTH_SHORT).show()
            }
        }

        private fun logoutUser() {
            auth.signOut()
            Toast.makeText(this, "Logged Out", Toast.LENGTH_SHORT).show()
        }*/
}