package com.example.tutorappextravaganza.dataclasses

import com.google.firebase.database.Exclude
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.DayOfWeek
import java.time.temporal.TemporalAdjusters

open class TimeBlock(
    @get:Exclude
    var id: String? = null,
    var timeFrom: Int? = null,
    var timeTo: Int? = null,
    var month: Int? = null,
    var week: Int? = null, // week of the month
    var day: Int? = null   // day of the week (0-6, where 0 is Sunday)
) {
    /**
     * Converts this TimeBlock into a Pair of LocalDateTime representing the start and end times.
     *
     * The timeFrom and timeTo are expected to be in the 4-digit format (e.g., 1400 means 14:00).
     *
     * @param year The year to use for the conversion. Defaults to the current year.
     * @return A Pair where first is the start LocalDateTime and second is the end LocalDateTime.
     */
    fun toDateTimePair(year: Int = LocalDate.now().year): Pair<LocalDateTime, LocalDateTime> {
        // Validate required fields
        val monthVal = month ?: throw IllegalArgumentException("Month is null")
        val weekVal = week ?: throw IllegalArgumentException("Week is null")
        val dayOfWeekInt = day ?: throw IllegalArgumentException("Day is null")
        val timeFromValue = timeFrom ?: throw IllegalArgumentException("timeFrom is null")
        val timeToValue = timeTo ?: throw IllegalArgumentException("timeTo is null")

        // Extract hours and minutes from timeFrom and timeTo.
        val fromHour = timeFromValue / 100
        val fromMinute = timeFromValue % 100
        val toHour = timeToValue / 100
        val toMinute = timeToValue % 100

        // Convert day (0 for Sunday, 1 for Monday, etc.) to Java's DayOfWeek.
        // Java's DayOfWeek enum: MONDAY=1, ..., SUNDAY=7.
        val dayOfWeek = if (dayOfWeekInt == 0) DayOfWeek.SUNDAY else DayOfWeek.of(dayOfWeekInt)

        // Create a LocalDate for the first day of the given month in the specified year.
        val firstDay = LocalDate.of(year, monthVal, 1)
        // Find the first occurrence of the desired day-of-week in that month.
        val firstOccurrence = firstDay.with(TemporalAdjusters.nextOrSame(dayOfWeek))
        // The target date is the first occurrence plus (week - 1) weeks.
        val targetDate = firstOccurrence.plusWeeks((weekVal - 1).toLong())

        // Build the start and end LocalDateTime using the computed target date and extracted times.
        val startDateTime = LocalDateTime.of(targetDate, LocalTime.of(fromHour, fromMinute))
        val endDateTime = LocalDateTime.of(targetDate, LocalTime.of(toHour, toMinute))

        return Pair(startDateTime, endDateTime)
    }

    fun getDate(year: Int = LocalDate.now().year): LocalDate {
        // Validate required fields
        val monthVal = month ?: throw IllegalArgumentException("Month is null")
        val weekVal = week ?: throw IllegalArgumentException("Week is null")
        val dayOfWeekInt = day ?: throw IllegalArgumentException("Day is null")

        // Convert day (0 for Sunday, 1 for Monday, etc.) to Java's DayOfWeek.
        val dayOfWeek = if (dayOfWeekInt == 0) DayOfWeek.SUNDAY else DayOfWeek.of(dayOfWeekInt)

        // Get the first day of the given month in the specified year.
        val firstDay = LocalDate.of(year, monthVal, 1)

        // Find the first occurrence of the specified day-of-week in the month.
        val firstOccurrence = firstDay.with(TemporalAdjusters.nextOrSame(dayOfWeek))

        // Compute the target date by adding (week - 1) weeks.
        val targetDate = firstOccurrence.plusWeeks((weekVal - 1).toLong())

        // Ensure that the computed date is still within the given month.
        if (targetDate.monthValue != monthVal) {
            throw IllegalArgumentException("Invalid week value: Computed date exceeds the month")
        }

        return targetDate
    }

    fun isWithin(other: TimeBlock): Boolean {
        return this.month == other.month && this.week == other.week && this.day == other.day &&
                this.timeFrom != null && this.timeTo != null &&
                other.timeFrom != null && other.timeTo != null &&
                this.timeFrom!! <= other.timeFrom!! && this.timeTo!! >= other.timeTo!!
    }

    fun conflictsWith(timeBlock: TimeBlock): Boolean {
        if (month == timeBlock.month && week == timeBlock.week && day == timeBlock.day) {
            val start2 = timeBlock.timeFrom
            val end2 = timeBlock.timeTo
            val start1 = timeFrom
            val end1 = timeTo
            if (end2 != null && start2 != null && end1 != null && start1 != null) {
                // Ensure no time overlaps
                if ((end1 < start2 && start1 < start2) || (start1 > end2 && end1 > end2)) {
                    return false
                }
            }
        }
        return true
    }
}
