package com.example.tutorappextravaganza.course_select

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tutorappextravaganza.R
import com.example.tutorappextravaganza.TutorHomeActivity
import com.example.tutorappextravaganza.dataclasses.Course
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class GradeSelectionActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: GradeAdapter
    private val database = FirebaseDatabase.getInstance()
    private val coursesRef = database.getReference("Course") // Path to all courses
    private val gradeLevels = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_grade_selection)

        // Retrieve the selected subject from the Intent
        val selectedSubject = intent.getStringExtra("selected_subject") ?: "Math"
        findViewById<TextView>(R.id.tvSelectedSubject).text = "Subject: $selectedSubject"

        recyclerView = findViewById(R.id.recyclerViewGrades)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val backbtn = findViewById<Button>(R.id.backgrad)

        backbtn.setOnClickListener {
            val intent = Intent(this, SubjectSelectionActivity::class.java)
            startActivity(intent)
        }

        // Fetch available grade levels for the selected subject from Firebase
        fetchGradesForSubject(selectedSubject)
    }

    private fun fetchGradesForSubject(selectedSubject: String) {
        coursesRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                gradeLevels.clear() // Clear old data

                for (courseSnapshot in snapshot.children) {
                    val gradeLevel = courseSnapshot.child("gradeLevel").getValue(String::class.java) ?: ""
                    val subject = courseSnapshot.child("subject").getValue(String::class.java) ?: ""

                    if (subject == selectedSubject && gradeLevel.isNotEmpty()) {
                        if (!gradeLevels.contains(gradeLevel)) { // Avoid duplicates
                            gradeLevels.add(gradeLevel)
                        }
                    }
                }

                // Map grade levels to Course objects (with subject preset)
                val gradeCourses = gradeLevels.map { grade ->
                    Course(id = "", gradeLevel = grade, subject = selectedSubject)
                }

                // Initialize the adapter with the fetched courses
                adapter = GradeAdapter(gradeCourses) { selectedGradeCourse ->
                    val finalCourse = Course(
                        subject = selectedSubject,
                        gradeLevel = selectedGradeCourse.gradeLevel
                    )
                    writeCourseToFirebase(finalCourse)
                }
                recyclerView.adapter = adapter
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(
                    this@GradeSelectionActivity,
                    "Database error: ${error.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

    private fun writeCourseToFirebase(finalCourse: Course) {
        // Get the current user ID from Firebase Auth
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (uid != null) {
            // Reference to the current user's "teaches" list
            val teachesRef = FirebaseDatabase.getInstance()
                .getReference("Users")
                .child(uid)
                .child("teaches")

            // First, check if the same course (subject & gradeLevel) is already in the teaches list
            teachesRef.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    var courseExists = false

                    for (courseSnapshot in snapshot.children) {
                        val subject = courseSnapshot.child("subject").getValue(String::class.java) ?: ""
                        val gradeLevel = courseSnapshot.child("gradeLevel").getValue(String::class.java) ?: ""
                        if (subject == finalCourse.subject && gradeLevel == finalCourse.gradeLevel) {
                            courseExists = true
                            break
                        }
                    }

                    if (courseExists) {
                        Toast.makeText(
                            this@GradeSelectionActivity,
                            "Course already exists",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        // Use the course's own id if it exists; otherwise generate a new one
                        finalCourse.id = teachesRef.push().key

                        // Use finalCourse.id as the key when writing the data
                        teachesRef.child(finalCourse.id!!).setValue(finalCourse)
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    Toast.makeText(
                                        this@GradeSelectionActivity,
                                        "Course added: ${finalCourse.subject} - ${finalCourse.gradeLevel}",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    // Optionally, finish the activity or navigate further
                                } else {
                                    Toast.makeText(
                                        this@GradeSelectionActivity,
                                        "Failed to add course",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(
                        this@GradeSelectionActivity,
                        "Database error: ${error.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
        }
    }
}