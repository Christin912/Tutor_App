package com.example.tutorappextravaganza

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tutorappextravaganza.dataclasses.TimeBlock
import com.example.tutorappextravaganza.timeblocks.TimeBlockAdapter
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class TutorAvailabilityActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: TimeBlockAdapter
    private val timeBlocks = mutableListOf<TimeBlock>()
    private val database = FirebaseDatabase.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val userId = auth.currentUser?.uid ?: ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_tutor_availability)

        recyclerView = findViewById(R.id.recyclerViewTimeBlocks)
        recyclerView.layoutManager = LinearLayoutManager(this)

        if (userId.isNotEmpty()) {
            fetchTimeBlocks()
        } else {
            Toast.makeText(this, "User not logged in!", Toast.LENGTH_SHORT).show()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val dayText = findViewById<EditText>(R.id.day)
        val timeStartText = findViewById<EditText>(R.id.time_start)
        val timeEndText = findViewById<EditText>(R.id.time_end)
        val selected_month = 2;
        val selected_week = 1;
        val addTimeblockButton = findViewById<Button>(R.id.add_timeblock)
        val backbtn = findViewById<Button>(R.id.backavail)

        backbtn.setOnClickListener {
            val intent = Intent(this, TutorHomeActivity::class.java)
            startActivity(intent)
        }

        addTimeblockButton.setOnClickListener {
            val uid = FirebaseAuth.getInstance().currentUser?.uid
            val selected_day = dayText.text.toString().toIntOrNull()
            val selectedTimeStart = timeStartText.text.toString().toIntOrNull() //1000
            val selectedTimeEnd = timeEndText.text.toString().toIntOrNull() //1100

            if (selectedTimeStart != null && selectedTimeEnd != null) {
                if (uid != null) {
                    val timeblocksRef = FirebaseDatabase.getInstance()
                        .getReference("Users")
                        .child(uid)
                        .child("availableTimeBlocks")

                    timeblocksRef.addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            var validTimeBlock = true;
                            for (timeBlockSnapshot in snapshot.children) {
                                val existing_month =
                                    timeBlockSnapshot.child("month").getValue(Int::class.java) ?: 0
                                if (selected_month == existing_month) {
                                    val existing_week =
                                        timeBlockSnapshot.child("week").getValue(Int::class.java)
                                            ?: 0
                                    if (selected_week == existing_week) {
                                        val existing_day =
                                            timeBlockSnapshot.child("day").getValue(Int::class.java)
                                                ?: 0
                                        if (selected_day == existing_day) {
                                            val existingTimeStart =
                                                timeBlockSnapshot.child("timeFrom")
                                                    .getValue(Int::class.java) ?: 0
                                            val existingTimeEnd = timeBlockSnapshot.child("timeTo")
                                                .getValue(Int::class.java) ?: 0
                                            // Ensure no time overlaps
                                            if ((selectedTimeEnd < existingTimeStart && selectedTimeStart < existingTimeStart) || (selectedTimeStart > existingTimeEnd && selectedTimeEnd > existingTimeEnd)) {
                                                // Valid
                                            } else {
                                                validTimeBlock = false
                                            }
                                        }
                                    }
                                }
                            }
                            // Outside of checks
                            if (validTimeBlock) {
                                // Make it
                                val newTimeBlock = TimeBlock(
                                    timeTo = selectedTimeStart,
                                    timeFrom = selectedTimeEnd,
                                    month = selected_month,
                                    week = selected_week,
                                    day = selected_day
                                )
                                newTimeBlock.id = timeblocksRef.push().key

                                timeblocksRef.child(newTimeBlock.id!!).setValue(newTimeBlock)
                                    .addOnCompleteListener { task ->
                                        if (task.isSuccessful) {
                                            Toast.makeText(
                                                this@TutorAvailabilityActivity,
                                                "Session added: ${newTimeBlock.timeFrom} - ${newTimeBlock.timeTo}",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                            // Optionally, finish the activity or navigate further
                                        } else {
                                            Toast.makeText(
                                                this@TutorAvailabilityActivity,
                                                "Failed to add course",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    }
                            }
                        }

                        override fun onCancelled(error: DatabaseError) {
                            Toast.makeText(
                                this@TutorAvailabilityActivity,
                                "Database error: ${error.message}",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    })
                }
            }
        }
    }

    private fun fetchTimeBlocks() {
        val ref = database.getReference("Users/$userId/availableTimeBlocks")

        ref.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                timeBlocks.clear()

                for (timeBlockSnapshot in snapshot.children) {
                    val timeBlock = timeBlockSnapshot.getValue(TimeBlock::class.java)
                    timeBlock?.id = timeBlockSnapshot.key // Assign ID from Firebase key

                    if (timeBlock != null) {
                        timeBlocks.add(timeBlock)
                    }
                }

                // Set adapter after fetching data
                adapter = TimeBlockAdapter(timeBlocks, userId)
                recyclerView.adapter = adapter
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@TutorAvailabilityActivity, "Database error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

}