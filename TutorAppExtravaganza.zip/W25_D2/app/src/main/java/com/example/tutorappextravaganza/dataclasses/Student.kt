package com.example.tutorappextravaganza.dataclasses

import com.google.firebase.database.Exclude

data class Student(
    @get: Exclude
    var id: String? = null,
    var lastName: String? = null,
    var firstName: String? = null,
    var email: String? = null,
    //var password: String? = null,
    var studentSchedule: MutableList<Session> = mutableListOf() // Sessions the student is enrolled in
)