package com.example.tutorappextravaganza

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.tutorappextravaganza.dataclasses.User
import com.example.tutorappextravaganza.tutorSearch.TutorSearchActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class RegistryActivity : AppCompatActivity() {

    var auth = FirebaseAuth.getInstance()
    var database = FirebaseDatabase.getInstance().reference

    private lateinit var btnStudent: Button
    private lateinit var btnTutor: Button
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnRegister: Button
    private lateinit var etFirstname: EditText
    private lateinit var etLastname: EditText

    private var selectedRole: String? = null // Stores the selected role ("Student" or "Tutor")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        btnStudent = findViewById(R.id.btnStudent)
        btnTutor = findViewById(R.id.btnTutor)
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        btnRegister = findViewById(R.id.btnRegister)
        etFirstname = findViewById(R.id.etFirstname)
        etLastname = findViewById(R.id.etLastname)


        btnStudent.setOnClickListener { selectRole("Student") }
        btnTutor.setOnClickListener { selectRole("Tutor") }

        btnRegister.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()
            val first_name = etFirstname.text.toString().trim()
            val last_name = etLastname.text.toString().trim()

            if (selectedRole == null) {
                etEmail.error = "Please select Student or Tutor"
                return@setOnClickListener
            }

            if (email.isEmpty()) {
                etEmail.error = "Email is required"
                return@setOnClickListener
            }

            if (password.length < 8 || password.length > 15) {
                etPassword.error = "Password must be 8-15 characters"
                return@setOnClickListener
            }

            if (first_name.isEmpty()) {
                etFirstname.error = "First name is required"
            }

            if (last_name.isEmpty()) {
                etLastname.error = "Last name is required"
            }

            // At this point, the selectedRole, email, and password can be sent to the backend
            registerUser(email, password, last_name, first_name, selectedRole!!)
        }
    }

    private fun selectRole(role: String) {
        selectedRole = role

        if (role == "Student") {
            btnStudent.setBackgroundColor(Color.parseColor("#4CAF50")) // Green when selected
            btnTutor.setBackgroundColor(Color.parseColor("#D6D6D6")) // Gray when deselected
        } else {
            btnTutor.setBackgroundColor(Color.parseColor("#4CAF50")) // Green when selected
            btnStudent.setBackgroundColor(Color.parseColor("#D6D6D6")) // Gray when deselected
        }
    }

    fun registerUser(
        email: String,
        password: String,
        lastName: String,
        firstName: String,
        role: String
    ){
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val userId = auth.currentUser?.uid
                    if (userId != null) {
                        saveUserToDatabase(userId, lastName, firstName, email, role)
                    }

                } else {
                    Toast.makeText(this, "Registration Failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show();
                }
            }
    }


    private fun saveUserToDatabase(
        userId: String,
        lastName: String,
        firstName: String,
        email: String,
        role: String
    ) {

        val user = User(userId, lastName, firstName, email, role) //could change to admin/tutor/student

        database.child("Users").child(userId).setValue(user) //change to tutor/student/admin
            .addOnSuccessListener{
                Toast.makeText(this, "Registration success!", Toast.LENGTH_SHORT).show();
                database.child("Users").child(auth.currentUser!!.uid).get()
                    .addOnSuccessListener { snapshot ->
                        if (snapshot.exists()) {
                            val role = snapshot.child("role").value.toString()
                            if (role == "Tutor") {
                                val intent = Intent(this, TutorHomeActivity::class.java)
                                startActivity(intent)
                            } else {
                                val intent = Intent(this, TutorSearchActivity::class.java)
                                startActivity(intent)
                            }
                        } else {
                            Toast.makeText(this, "User Not Found", Toast.LENGTH_LONG).show()
                        }
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(this, "Failed to Retrieve Data: ${e.message}", Toast.LENGTH_LONG).show()
                    }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to register user in the database.", Toast.LENGTH_SHORT).show();
            }
    }
}