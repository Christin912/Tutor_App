package com.example.tutorappextravaganza.session_select
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.tutorappextravaganza.dataclasses.Course
import com.example.tutorappextravaganza.dataclasses.TimeBlock
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class SessionSelectByTimeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val course: Course = intent.getParcelableExtra("courses") ?: Course(null,"Math","7")
        val tutorId: String = intent.getStringExtra("tutorId") ?: "W2n8p5eYSzdNR5sOVCyAvXC6j0Q2"
        setContent {
            CalendarScreen2(course, tutorId)
        }
    }
}

@Composable
fun CalendarScreen2(course: Course, tutorId: String ) {
    var selectedMonth by remember { mutableStateOf(LocalDate.now().monthValue) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    val daysInMonth = LocalDate.of(LocalDate.now().year, selectedMonth, 1).lengthOfMonth()
    val currentUser = FirebaseAuth.getInstance().currentUser
    val studentId = currentUser?.uid ?: "rB7X5ekeQaTTWBKDVdv2jyLsVew2"
    var showTimeSelection by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Select a Month", style = MaterialTheme.typography.headlineMedium)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            Button(onClick = { if (selectedMonth > 1) selectedMonth-- }) {
                Text("Previous")
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text("Month: $selectedMonth")
            Spacer(modifier = Modifier.width(16.dp))
            Button(onClick = { if (selectedMonth < 12) selectedMonth++ }) {
                Text("Next")
            }
        }

        Text("Selected Date: ${selectedDate.dayOfMonth}/${selectedDate.monthValue}", style = MaterialTheme.typography.bodyLarge)
        LazyVerticalGrid(columns = GridCells.Fixed(7), modifier = Modifier.padding(8.dp)) {
            items(daysInMonth) { day ->
                val date = LocalDate.of(LocalDate.now().year, selectedMonth, day + 1)
                Text(
                    text = date.format(DateTimeFormatter.ofPattern("d")),
                    modifier = Modifier
                        .padding(8.dp)
                        .clickable {
                            selectedDate = date
                            showTimeSelection = true
                        }
                )
            }
        }

        if (showTimeSelection) {
            openTimeSelection2(studentId, course, selectedDate, onClose = {
                showTimeSelection = false
            })
        }
    }
}

@Composable
fun openTimeSelection2(studentId: String, course: Course, selectedDate: LocalDate, onClose: () -> Unit) {
    val database = FirebaseDatabase.getInstance().reference
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedTimeFrom by remember { mutableStateOf<Int?>(null) }
    var selectedTimeTo by remember { mutableStateOf<Int?>(null) }
    var availableTimePairs by remember { mutableStateOf(listOf<Pair<Int, List<Int>>>()) }
    var tutorsWithCourse by remember { mutableStateOf(listOf<String>()) }
    var filteredTutors by remember { mutableStateOf(listOf<Pair<String, String>>()) } // (TutorID, TutorName)
    var availableSlotsText by remember { mutableStateOf<String?>(null) } // Stores available slots for tutor

    // Fetch tutors who teach the selected course
    LaunchedEffect(course, selectedDate) {
        selectedTimeFrom = null
        selectedTimeTo = null
        availableTimePairs = emptyList()
        filteredTutors = emptyList()
        availableSlotsText = null

        val usersSnapshot = database.child("Users").get().await()
        val tutors = mutableListOf<String>()
        val allAvailableBlocks = mutableListOf<TimeBlock>()

        for (user in usersSnapshot.children) {
            val userId = user.key ?: continue
            val teaches = user.child("teaches").children.map { it.getValue(Course::class.java) }

            if (teaches.any { it?.gradeLevel == course.gradeLevel && it?.subject == course.subject }) {
                tutors.add(userId)
                val tutorBlocks = user.child("availableTimeBlocks").children.mapNotNull {
                    it.getValue(TimeBlock::class.java)
                }.filter { it.getDate().isEqual(selectedDate) }
                allAvailableBlocks.addAll(tutorBlocks)
            }
        }

        tutorsWithCourse = tutors

        val timePairs = mutableListOf<Pair<Int, List<Int>>>()
        allAvailableBlocks.forEach { block ->
            var time = block.timeFrom ?: 0
            while (time + 100 <= (block.timeTo ?: 0)) {
                val validEndTimes = mutableListOf<Int>()

                if (time + 100 <= block.timeTo!!) validEndTimes.add(time + 100)
                if (time + 200 <= block.timeTo!!) validEndTimes.add(time + 200)

                if (validEndTimes.isNotEmpty()) {
                    timePairs.add(Pair(time, validEndTimes))
                }
                time += 100
            }
        }
        availableTimePairs = timePairs
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Select Time Slot", style = MaterialTheme.typography.headlineMedium)

        if (availableTimePairs.isNotEmpty()) {
            var expandedFrom by remember { mutableStateOf(false) }
            Box(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Button(onClick = { expandedFrom = true }) {
                    Text(selectedTimeFrom?.let { formatTime(it) } ?: "Select Start Time")
                }
                DropdownMenu(expanded = expandedFrom, onDismissRequest = { expandedFrom = false }) {
                    availableTimePairs.map { it.first }.distinct().forEach { time ->
                        DropdownMenuItem(
                            text = { Text(formatTime(time)) },
                            onClick = {
                                selectedTimeFrom = time
                                selectedTimeTo = null
                                expandedFrom = false
                            }
                        )
                    }
                }
            }

            if (selectedTimeFrom != null) {
                var expandedTo by remember { mutableStateOf(false) }
                val validEndTimes = availableTimePairs.find { it.first == selectedTimeFrom }?.second ?: listOf()

                if (validEndTimes.isNotEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        Button(onClick = { expandedTo = true }) {
                            Text(selectedTimeTo?.let { formatTime(it) } ?: "Select End Time")
                        }
                        DropdownMenu(expanded = expandedTo, onDismissRequest = { expandedTo = false }) {
                            validEndTimes.forEach { time ->
                                DropdownMenuItem(
                                    text = { Text(formatTime(time)) },
                                    onClick = {
                                        selectedTimeTo = time
                                        expandedTo = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        } else {
            Text("No available slots for this date", style = MaterialTheme.typography.bodyMedium)
        }

        // Tutor Search Button
        Button(onClick = {
            if (selectedTimeFrom != null && selectedTimeTo != null) {
                coroutineScope.launch {
                    findTutorsWithAvailability(database, tutorsWithCourse, selectedTimeFrom!!, selectedTimeTo!!) { tutors ->
                        filteredTutors = tutors
                    }
                }
            }
        }) {
            Text("Find Available Tutors")
        }

        LazyColumn {
            items(filteredTutors) { tutor ->
                TutorItem(tutor) {
                    coroutineScope.launch {
                        val (hasConflict, availableSlots, conflictMessage) = checkForConflicts(
                            database,
                            studentId,
                            tutor.first,
                            selectedTimeFrom!!,
                            selectedTimeTo!!,
                            selectedDate // ✅ Pass selectedDate
                        )
                        if (!hasConflict) {
                            bookSession(
                                database,
                                studentId,
                                tutor.first,
                                selectedTimeFrom!!,
                                selectedTimeTo!!,
                                course,
                                selectedDate, // ✅ Pass selectedDate to store month, week, and day
                                context
                            )
                        } else {
                            availableSlotsText = availableSlots
                            Toast.makeText(context, conflictMessage, Toast.LENGTH_SHORT).show() // ✅ Shows who has the conflict
                        }
                    }
                }
            }
        }

        // Display available time slots if there was a conflict
        if (!availableSlotsText.isNullOrEmpty()) {
            Text("Tutor's Available Slots: $availableSlotsText", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(16.dp))
        }

        Button(onClick = { onClose() }) {
            Text("Close")
        }
    }
}

@Composable
fun TutorItem(tutor: Pair<String, String>, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(tutor.second, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

suspend fun findTutorsWithAvailability(
    database: DatabaseReference,
    tutors: List<String>,
    timeFrom: Int,
    timeTo: Int,
    onResult: (List<Pair<String, String>>) -> Unit
) {
    val availableTutors = mutableListOf<Pair<String, String>>()
    val usersSnapshot = database.child("Users").get().await()

    for (user in usersSnapshot.children) {
        val userId = user.key ?: continue
        if (userId in tutors) {
            val tutorName = "${user.child("firstName").value} ${user.child("lastName").value}"
            val availableBlocks = user.child("availableTimeBlocks").children.mapNotNull {
                it.getValue(TimeBlock::class.java)
            }

            val isAvailable = availableBlocks.any { it.timeFrom!! <= timeFrom && it.timeTo!! >= timeTo }

            if (isAvailable) {
                availableTutors.add(Pair(userId, tutorName))
            }
        }
    }
    onResult(availableTutors)
}

suspend fun checkForConflicts(
    database: DatabaseReference,
    studentId: String,
    tutorId: String,
    timeFrom: Int,
    timeTo: Int,
    selectedDate: LocalDate
): Triple<Boolean, String, String> { // ✅ Now returns detailed conflict info
    val studentScheduleSnapshot = database.child("Users").child(studentId).child("schedule").get().await()
    val tutorScheduleSnapshot = database.child("Users").child(tutorId).child("schedule").get().await()
    val tutorAvailabilitySnapshot = database.child("Users").child(tutorId).child("availableTimeBlocks").get().await()

    // Filter only time blocks that match the selected date
    val studentTimeBlocks = studentScheduleSnapshot.children.mapNotNull {
        it.child("timeBlock").getValue(TimeBlock::class.java)
    }.filter { it.isValid() && it.getDate() == selectedDate }

    val tutorTimeBlocks = tutorScheduleSnapshot.children.mapNotNull {
        it.child("timeBlock").getValue(TimeBlock::class.java)
    }.filter { it.isValid() && it.getDate() == selectedDate }
        .sortedBy { it.timeFrom }

    val tutorAvailableBlocks = tutorAvailabilitySnapshot.children.mapNotNull {
        it.getValue(TimeBlock::class.java)
    }.filter { it.isValid() && it.getDate() == selectedDate }
        .sortedBy { it.timeFrom }

    val requestedTimeBlock = TimeBlock(timeFrom = timeFrom, timeTo = timeTo, month = selectedDate.monthValue, week = (selectedDate.dayOfMonth - 1) / 7 + 1, day = selectedDate.dayOfWeek.value)

    val studentConflict = studentTimeBlocks.any { it.conflictsWith(requestedTimeBlock) }
    val tutorConflict = tutorTimeBlocks.any { it.conflictsWith(requestedTimeBlock) }

    val hasConflict = studentConflict || tutorConflict

    // Compute available slots by checking gaps in scheduled sessions
    val availableSlots = mutableListOf<Pair<Int, Int>>()

    for (availableBlock in tutorAvailableBlocks) {
        var currentStart = availableBlock.timeFrom!!
        val end = availableBlock.timeTo!!

        for (scheduled in tutorTimeBlocks) {
            if (scheduled.timeFrom!! >= end) break // No more relevant scheduled sessions

            // If there's a gap between the current available block and the scheduled session, add it
            if (currentStart < scheduled.timeFrom!!) {
                availableSlots.add(Pair(currentStart, scheduled.timeFrom!!))
            }
            // Move the start forward to the end of the scheduled session
            if (scheduled.timeTo!! > currentStart) {
                currentStart = scheduled.timeTo!!
            }
        }

        // If there's still free time after the last scheduled session, add it
        if (currentStart < end) {
            availableSlots.add(Pair(currentStart, end))
        }
    }

    val availableSlotsText = if (availableSlots.isNotEmpty()) {
        availableSlots.joinToString(", ") { "${formatTime(it.first)} to ${formatTime(it.second)}" }
    } else {
        "No open slots"
    }

    // Determine conflict message
    val conflictMessage = when {
        studentConflict && tutorConflict -> "Time slot conflicts with both the student's and tutor's schedule!"
        studentConflict -> "Time slot conflicts with the student's schedule!"
        tutorConflict -> "Time slot conflicts with the tutor's schedule!"
        else -> ""
    }

    return Triple(hasConflict, availableSlotsText, conflictMessage) // ✅ Return detailed conflict message
}

fun bookSession(
    database: DatabaseReference,
    studentId: String,
    tutorId: String,
    timeFrom: Int,
    timeTo: Int,
    course: Course,
    selectedDate: LocalDate,
    context: android.content.Context
) {
    val sessionKey = database.child("Sessions").push().key ?: return

    // Calculate `month`, `week`, and `day` from the selectedDate
    val month = selectedDate.monthValue
    val week = (selectedDate.dayOfMonth - 1) / 7 + 1 // Week of the month
    val day = selectedDate.dayOfWeek.value // Java's `DayOfWeek` uses 1 for Monday, ..., 7 for Sunday

    val sessionData = mapOf(
        "course" to mapOf(
            "gradeLevel" to course.gradeLevel,
            "subject" to course.subject
        ),
        "student" to mapOf("id" to studentId),
        "tutor" to mapOf("id" to tutorId),
        "timeBlock" to mapOf(
            "timeFrom" to timeFrom,
            "timeTo" to timeTo,
            "month" to month,
            "week" to week,
            "day" to day
        )
    )

    val studentScheduleRef = database.child("Users").child(studentId).child("schedule").child(sessionKey)
    val tutorScheduleRef = database.child("Users").child(tutorId).child("schedule").child(sessionKey)
    val sessionPath = database.child("Sessions").child(sessionKey)

    sessionPath.setValue(sessionData).addOnCompleteListener { task ->
        if (task.isSuccessful) {
            studentScheduleRef.setValue(sessionData)
            tutorScheduleRef.setValue(sessionData)
            Toast.makeText(context, "Session booked successfully", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Failed to book session", Toast.LENGTH_SHORT).show()
        }
    }
}

// Function to check if a time block conflicts with existing bookings
fun TimeBlock.conflictsWith2(timeFrom: Int, timeTo: Int): Boolean {
    return this.timeFrom!! < timeTo && this.timeTo!! > timeFrom
}

fun TimeBlock.isValid(): Boolean {
    return this.month != null && this.week != null && this.day != null &&
            this.timeFrom != null && this.timeTo != null
}

