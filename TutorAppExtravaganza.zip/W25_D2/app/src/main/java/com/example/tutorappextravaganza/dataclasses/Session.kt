package com.example.tutorappextravaganza.dataclasses

import com.google.firebase.database.Exclude

data class Session(
    @get: Exclude
    var sessionId: String? = null,
    var course: Course,
    var student: User,
    var tutor: User,
    var timeBlock: TimeBlock
)

