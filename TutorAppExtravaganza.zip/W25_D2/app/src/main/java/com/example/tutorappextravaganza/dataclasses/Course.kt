package com.example.tutorappextravaganza.dataclasses

import com.google.firebase.database.Exclude
/* exclude is to prevent id from being stored in the DB (will want to
auto-generate this when writing to DB by using push()
 */

open class Course (
    @get: Exclude
    var id: String? = null,
    var subject: String? = null,
    var gradeLevel: String? = null,
)