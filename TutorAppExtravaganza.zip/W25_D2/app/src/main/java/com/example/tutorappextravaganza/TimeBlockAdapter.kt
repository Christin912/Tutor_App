package com.example.tutorappextravaganza.timeblocks

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.tutorappextravaganza.R
import com.example.tutorappextravaganza.dataclasses.TimeBlock
import com.google.firebase.database.FirebaseDatabase

class TimeBlockAdapter(
    private val timeBlocks: MutableList<TimeBlock>,
    private val userId: String // Pass UID to manage user-specific data
) : RecyclerView.Adapter<TimeBlockAdapter.TimeBlockViewHolder>() {

    class TimeBlockViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvDay: TextView = view.findViewById(R.id.tvDay)
        val tvTimeFrom: TextView = view.findViewById(R.id.tvTimeFrom)
        val tvTimeTo: TextView = view.findViewById(R.id.tvTimeTo)
        val btnDelete: Button = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TimeBlockViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_time_block, parent, false)
        return TimeBlockViewHolder(view)
    }

    override fun onBindViewHolder(holder: TimeBlockViewHolder, position: Int) {
        val timeBlock = timeBlocks[position]

        // Convert day index to actual day name
        val daysOfWeek = listOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
        val dayName = timeBlock.day?.let { daysOfWeek.getOrNull(it) } ?: "Unknown"

        // Display details
        holder.tvDay.text = "Day: $dayName"
        holder.tvTimeFrom.text = "From: ${timeBlock.timeFrom} hrs"
        holder.tvTimeTo.text = "To: ${timeBlock.timeTo} hrs"

        // Delete button action
        holder.btnDelete.setOnClickListener {
            timeBlock.id?.let { id ->
                deleteTimeBlockFromFirebase(id, position)
            }
        }
    }

    override fun getItemCount(): Int = timeBlocks.size

    private fun deleteTimeBlockFromFirebase(timeBlockId: String, position: Int) {
        val ref = FirebaseDatabase.getInstance()
            .getReference("Users/$userId/availableTimeBlocks/$timeBlockId")

        ref.removeValue().addOnSuccessListener {
            // Remove item from list and notify adapter
            timeBlocks.removeAt(position)
            notifyItemRemoved(position)
        }
    }
}
