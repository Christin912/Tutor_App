package com.example.tutorappextravaganza.tutorSearch

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tutorappextravaganza.R
import com.example.tutorappextravaganza.dataclasses.Course
import com.example.tutorappextravaganza.dataclasses.TimeBlock
import com.example.tutorappextravaganza.dataclasses.User
import com.google.firebase.database.*

class TutorSearchActivity : AppCompatActivity() {

    private lateinit var subjectSpinner: Spinner
    private lateinit var gradeSpinner: Spinner
    private lateinit var searchButton: Button
    private lateinit var recyclerView: RecyclerView
    private lateinit var tutorAdapter: TutorAdapter
    private val tutorList = mutableListOf<User>()

    // For subject & grade filtering (from Course node)
    private val coursesList = mutableListOf<Course>()

    // UI elements for optional availableTimeBlock filtering (using spinners)
    private lateinit var cbFilterAvailability: CheckBox
    private lateinit var layoutAvailabilityFilters: LinearLayout
    private lateinit var spinnerAvailMonth: Spinner
    private lateinit var spinnerAvailWeek: Spinner
    private lateinit var spinnerAvailDay: Spinner
    private lateinit var spinnerAvailTimeFrom: Spinner
    private lateinit var spinnerAvailTimeTo: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tutor_search)

        // Main filtering UI (subject & grade)
        subjectSpinner = findViewById(R.id.spinnerSubject)
        gradeSpinner = findViewById(R.id.spinnerGrade)
        searchButton = findViewById(R.id.btnSearch)
        recyclerView = findViewById(R.id.recyclerViewTutors)
        recyclerView.layoutManager = LinearLayoutManager(this)
        tutorAdapter = TutorAdapter(tutorList)
        recyclerView.adapter = tutorAdapter

        // Availability filter UI (using spinners)
        cbFilterAvailability = findViewById(R.id.cbFilterAvailability)
        layoutAvailabilityFilters = findViewById(R.id.layoutAvailabilityFilters)
        spinnerAvailMonth = findViewById(R.id.spinnerAvailMonth)
        spinnerAvailWeek = findViewById(R.id.spinnerAvailWeek)
        spinnerAvailDay = findViewById(R.id.spinnerAvailDay)
        spinnerAvailTimeFrom = findViewById(R.id.spinnerAvailTimeFrom)
        spinnerAvailTimeTo = findViewById(R.id.spinnerAvailTimeTo)

        // Hide availability filters by default.
        layoutAvailabilityFilters.visibility = View.GONE
        cbFilterAvailability.setOnCheckedChangeListener { _, isChecked ->
            layoutAvailabilityFilters.visibility = if (isChecked) View.VISIBLE else View.GONE
        }

        // Populate the availability filter spinners with an "Any" option.
        populateAvailabilitySpinners()

        // Fetch courses from Firebase to populate subject spinner.
        fetchCourses()

        subjectSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?, view: View?, position: Int, id: Long
            ) {
                val selectedSubject = subjectSpinner.selectedItem as String
                updateGradeSpinner(selectedSubject)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Set up the search button to query tutors based on selected filters.
        searchButton.setOnClickListener {
            val selectedSubject = subjectSpinner.selectedItem as? String ?: ""
            val selectedGrade = gradeSpinner.selectedItem as? String ?: ""
            searchTutors(selectedSubject, selectedGrade)
        }
    }

    /**
     * Populates the availability filter spinners.
     * Each spinner includes an "Any" option as the first item.
     */
    private fun populateAvailabilitySpinners() {
        // "Any" option as the first item in each list.
        val anyOption = "Any"

        // Month: "Any" + 1 to 12.
        val months = listOf(anyOption) + (1..12).map { it.toString() }
        // Week: "Any" + 1 to 4.
        val weeks = listOf(anyOption) + (1..4).map { it.toString() }
        // Day: "Any" + 0 to 6.
        val days = listOf(anyOption) + (0..6).map { it.toString() }
        // Time: "Any" + hours 0 to 23 multiplied by 100.
        val times = listOf(anyOption) + (0..23).map { (it * 100).toString() }

        spinnerAvailMonth.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_item, months
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spinnerAvailWeek.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_item, weeks
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spinnerAvailDay.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_item, days
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spinnerAvailTimeFrom.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_item, times
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spinnerAvailTimeTo.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_item, times
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    // Fetch courses from the "Course" node to populate subject spinner.
    private fun fetchCourses() {
        val coursesRef = FirebaseDatabase.getInstance().getReference("Course")
        coursesRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                coursesList.clear()
                for (courseSnap in snapshot.children) {
                    val course = courseSnap.getValue(Course::class.java)
                    if (course != null) {
                        coursesList.add(course)
                    }
                }
                // Populate subject spinner with distinct subjects.
                val subjects = coursesList.mapNotNull { it.subject }.distinct()
                if (subjects.isNotEmpty()) {
                    val subjectAdapter = ArrayAdapter(
                        this@TutorSearchActivity,
                        android.R.layout.simple_spinner_item,
                        subjects
                    )
                    subjectAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    subjectSpinner.adapter = subjectAdapter
                }
            }
            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@TutorSearchActivity, "Error fetching courses: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    // Update grade spinner based on the selected subject.
    private fun updateGradeSpinner(selectedSubject: String) {
        val gradeLevels = coursesList.filter { it.subject == selectedSubject }
            .mapNotNull { it.gradeLevel }
            .distinct()
        if (gradeLevels.isNotEmpty()) {
            val gradeAdapter = ArrayAdapter(
                this@TutorSearchActivity,
                android.R.layout.simple_spinner_item,
                gradeLevels
            )
            gradeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            gradeSpinner.adapter = gradeAdapter
        } else {
            gradeSpinner.adapter = null
        }
    }

    // Query the "Users" node and filter tutors based on selected subject, grade, and (optionally) availability.
    private fun searchTutors(selectedSubject: String, selectedGrade: String) {
        val usersRef = FirebaseDatabase.getInstance().getReference("Users")
        usersRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                tutorList.clear()
                for (userSnapshot in snapshot.children) {
                    val role = userSnapshot.child("role").getValue(String::class.java)
                    if (role == "Tutor") {
                        val user = userSnapshot.getValue(User::class.java)
                        if (user != null) {
                            user.id = userSnapshot.key
                            // Use helper method to get teaches list (from the map) for subject & grade filtering.
                            val teachesList = user.getTeachesList()
                            val matchingCourse = teachesList.any {
                                it.subject == selectedSubject && it.gradeLevel == selectedGrade
                            }
                            if (!matchingCourse) continue

                            // If filtering by availability is enabled, further filter by availableTimeBlock attributes.
                            if (cbFilterAvailability.isChecked) {
                                // Retrieve filter criteria from the availability spinners.
                                // If "Any" is selected, we treat that filter as null.
                                val filterMonth = spinnerAvailMonth.selectedItem?.toString().let {
                                    if (it == "Any") null else it?.toIntOrNull()
                                }
                                val filterWeek = spinnerAvailWeek.selectedItem?.toString().let {
                                    if (it == "Any") null else it?.toIntOrNull()
                                }
                                val filterDay = spinnerAvailDay.selectedItem?.toString().let {
                                    if (it == "Any") null else it?.toIntOrNull()
                                }
                                val filterTimeFrom = spinnerAvailTimeFrom.selectedItem?.toString().let {
                                    if (it == "Any") null else it?.toIntOrNull()
                                }
                                val filterTimeTo = spinnerAvailTimeTo.selectedItem?.toString().let {
                                    if (it == "Any") null else it?.toIntOrNull()
                                }

                                var availabilityMatches = false
                                if (userSnapshot.hasChild("availableTimeBlocks")) {
                                    val availSnapshot = userSnapshot.child("availableTimeBlocks")
                                    for (timeBlockSnap in availSnapshot.children) {
                                        val timeBlock = timeBlockSnap.getValue(TimeBlock::class.java)
                                        if (timeBlock != null) {
                                            // For each provided filter that is not null, check for a match.
                                            if (filterMonth != null && timeBlock.month != filterMonth) continue
                                            if (filterWeek != null && timeBlock.week != filterWeek) continue
                                            if (filterDay != null && timeBlock.day != filterDay) continue
                                            if (filterTimeFrom != null && timeBlock.timeFrom != filterTimeFrom) continue
                                            if (filterTimeTo != null && timeBlock.timeTo != filterTimeTo) continue
                                            // This timeBlock meets all provided criteria.
                                            availabilityMatches = true
                                            break
                                        }
                                    }
                                }
                                if (!availabilityMatches) continue
                            }
                            tutorList.add(user)
                        }
                    }
                }
                tutorAdapter.notifyDataSetChanged()
                if (tutorList.isEmpty()) {
                    Toast.makeText(
                        this@TutorSearchActivity,
                        "No tutors found for $selectedSubject ($selectedGrade)" +
                                if (cbFilterAvailability.isChecked) " with the given availability filter" else "",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@TutorSearchActivity, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}