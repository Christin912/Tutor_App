package com.example.tutorappextravaganza

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.tutorappextravaganza.dataclasses.User


class RegisterLoginActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

//        val emailEditText = findViewById<EditText>(R.id.emailEditText)
//        val passwordEditText = findViewById<EditText>(R.id.passwordEditText)
//        val registerButton = findViewById<Button>(R.id.registerButton)
//        val loginButton = findViewById<Button>(R.id.loginButton)
//        //need xml references
//
//        // Register user
//        registerButton.setOnClickListener {
//            val email = emailEditText.text.toString()
//            val password = passwordEditText.text.toString()
//            //get more val for first and last name
//            registerUser(email, password, lastName = "lastName", firstName = "firstName", role = "Tutor")
//        }
//
//        // Login user
//        loginButton.setOnClickListener {
//            val email = emailEditText.text.toString()
//            val password = passwordEditText.text.toString()
//            loginUser(email, password)
//        }


    }


}
