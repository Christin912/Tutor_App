package com.example.tutorappextravaganza

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.tutorappextravaganza.course_select.TutorViewCoursesActivity

class TutorHomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_tutor_home)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val availabilityButton = findViewById<Button>(R.id.availabilitybtn)
        val coursesButton = findViewById<Button>(R.id.coursesbtn)

        availabilityButton.setOnClickListener {
            val intent = Intent(this, TutorAvailabilityActivity::class.java)
            startActivity(intent)
        }

        coursesButton.setOnClickListener {
            val intent = Intent(this, TutorViewCoursesActivity::class.java)
            startActivity(intent)
        }
    }
}