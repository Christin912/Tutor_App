package com.example.tutorappextravaganza.course_select

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tutorappextravaganza.R
import com.example.tutorappextravaganza.dataclasses.Course
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class SubjectSelectionActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: SubjectAdapter
    private val database = FirebaseDatabase.getInstance()
    private val coursesRef = database.getReference("Course") // Make sure this matches Firebase path
    private val subjects = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_subject_selection)

        recyclerView = findViewById(R.id.recyclerViewSubjects)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val backbtn = findViewById<Button>(R.id.backsubj)

        backbtn.setOnClickListener {
            val intent = Intent(this, TutorViewCoursesActivity::class.java)
            startActivity(intent)
        }

        fetchSubjects()
    }

    private fun fetchSubjects() {
        coursesRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                subjects.clear() // Clear any old data before populating

                for (courseSnapshot in snapshot.children) {
                    val subject = courseSnapshot.child("subject").getValue(String::class.java) ?: ""
                    if (!subjects.contains(subject)) { // Avoid duplicates
                        subjects.add(subject)
                    }
                }
                // Create a list of Course objects where only the gradeLevel field is set
                val subjectCourses = subjects.map { subject -> Course(subject = subject) }

                adapter = SubjectAdapter(subjectCourses) { selectedCourse ->
                    // Navigate to GradeSelectionActivity with the selected subject
                    val intent = Intent(this@SubjectSelectionActivity, GradeSelectionActivity::class.java).apply {
                        putExtra("selected_subject", selectedCourse.subject)
                    }
                    startActivity(intent)
                }
                recyclerView.adapter = adapter
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@SubjectSelectionActivity, "Database error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun putExtra(s: String, subject: String?) {
        TODO("Not yet implemented")
    }
}
