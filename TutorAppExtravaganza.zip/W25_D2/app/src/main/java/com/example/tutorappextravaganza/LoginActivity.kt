package com.example.tutorappextravaganza

import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import com.example.tutorappextravaganza.course_select.SubjectSelectionActivity
import com.example.tutorappextravaganza.session_select.SessionSelectActivity
import com.example.tutorappextravaganza.tutorSearch.TutorSearchActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase


class LoginActivity : AppCompatActivity() {

    var auth = FirebaseAuth.getInstance()
    var database = FirebaseDatabase.getInstance().reference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Reference UI elements
        val emailEditText = findViewById<EditText>(R.id.etEmail)
        val passwordEditText = findViewById<EditText>(R.id.etPassword)
        val loginButton = findViewById<Button>(R.id.btnLogin)
        val registerButton = findViewById<Button>(R.id.btnRegister)

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            // Display validated input
            loginUser(email, password)
        }

        registerButton.setOnClickListener {
            val intent = Intent(this, RegistryActivity::class.java)
            startActivity(intent)
            }
    }

    fun loginUser(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this,"Login Success!", Toast.LENGTH_SHORT).show()
                    database.child("Users").child(auth.currentUser!!.uid).get()
                        .addOnSuccessListener { snapshot ->
                            if (snapshot.exists()) {
                                val role = snapshot.child("role").value.toString()
                                if (role == "Tutor") {
                                    val intent = Intent(this, TutorHomeActivity::class.java)
                                    startActivity(intent)
                                } else {
                                    val intent = Intent(this, SessionSelectActivity::class.java)
                                    startActivity(intent)
                                }
                            } else {
                                Toast.makeText(this, "User Not Found", Toast.LENGTH_LONG).show()
                            }
                        }
                        .addOnFailureListener { e ->
                            Toast.makeText(this, "Failed to Retrieve Data: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                } else {
                    Toast.makeText(this,"Login Failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }
}
