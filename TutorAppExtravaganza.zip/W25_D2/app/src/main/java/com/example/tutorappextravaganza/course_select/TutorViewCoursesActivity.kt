package com.example.tutorappextravaganza.course_select

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tutorappextravaganza.HomepageActivity
import com.example.tutorappextravaganza.R
import com.example.tutorappextravaganza.TutorHomeActivity
import com.example.tutorappextravaganza.dataclasses.Course
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class TutorViewCoursesActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: GradeAdapter
    private val auth = FirebaseAuth.getInstance()
    private val database = FirebaseDatabase.getInstance()
    private val tutorCoursesRef = database.getReference("Users/${auth.currentUser?.uid}/teaches")
    val coursesList = mutableListOf<Course>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_tutor_view_courses)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val backbtn = findViewById<Button>(R.id.backtutview)
        val addCoursebtn = findViewById<Button>(R.id.addCoursebtn)

        recyclerView = findViewById(R.id.recyclertutorviewcourses)
        recyclerView.layoutManager = LinearLayoutManager(this)

        backbtn.setOnClickListener {
            val intent = Intent(this, TutorHomeActivity::class.java)
            startActivity(intent)
        }

        addCoursebtn.setOnClickListener {
            val intent = Intent(this, SubjectSelectionActivity::class.java)
            startActivity(intent)
        }

        fetchCourses()
    }

    private fun fetchCourses() {
        tutorCoursesRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    coursesList.clear() // Clear old data
                    for (courseSnapshot in snapshot.children) {
                        val id = courseSnapshot.key ?: continue  // Use the key as ID
                        val gradeLevel =
                            courseSnapshot.child("gradeLevel").getValue(String::class.java) ?: ""
                        val subject =
                            courseSnapshot.child("subject").getValue(String::class.java) ?: ""
                        val course = Course(id, gradeLevel, subject)
                        coursesList.add(course)
                    }

                    val recyclerCoursesList = coursesList.map { course ->
                        Course(id = "", subject = course.subject, gradeLevel = "${course.gradeLevel}: ${course.subject}")
                    }

                    // Initialize the adapter with the fetched courses
                    adapter = GradeAdapter(recyclerCoursesList) { selectedGradeCourse ->
                    }
                    recyclerView.adapter = adapter
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(
                    this@TutorViewCoursesActivity,
                    "Database error: ${error.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }
}
