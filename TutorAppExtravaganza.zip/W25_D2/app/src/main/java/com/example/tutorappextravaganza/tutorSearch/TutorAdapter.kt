package com.example.tutorappextravaganza.tutorSearch

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.tutorappextravaganza.R
import com.example.tutorappextravaganza.dataclasses.User

class TutorAdapter(private val tutors: List<User>) : RecyclerView.Adapter<TutorAdapter.TutorViewHolder>() {

    inner class TutorViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvName: TextView = itemView.findViewById(R.id.tvTutorName)
        val tvEmail: TextView = itemView.findViewById(R.id.tvTutorEmail)
        val tvCourses: TextView = itemView.findViewById(R.id.tvTutorCourses)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TutorViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.tutor_item, parent, false)
        return TutorViewHolder(view)
    }

    override fun onBindViewHolder(holder: TutorViewHolder, position: Int) {
        val tutor = tutors[position]
        holder.tvName.text = "${tutor.firstName} ${tutor.lastName}"
        holder.tvEmail.text = tutor.email

        // Use getTeachesList() to obtain a list of courses, then join them into a string.
        val coursesText = if (tutor.getTeachesList().isNotEmpty()) {
            tutor.getTeachesList().joinToString(separator = ", ") { "${it.subject} (${it.gradeLevel})" }
        } else {
            "No courses assigned"
        }
        holder.tvCourses.text = coursesText
    }

    override fun getItemCount(): Int = tutors.size
}