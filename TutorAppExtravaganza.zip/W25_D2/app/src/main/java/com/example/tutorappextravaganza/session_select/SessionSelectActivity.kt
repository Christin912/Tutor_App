package com.example.tutorappextravaganza.session_select
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.tutorappextravaganza.dataclasses.Course
import com.example.tutorappextravaganza.dataclasses.Session
import com.example.tutorappextravaganza.dataclasses.TimeBlock
import com.example.tutorappextravaganza.dataclasses.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.Exclude
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.GenericTypeIndicator
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class SessionSelectActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val course: Course = intent.getParcelableExtra("course") ?: Course()
        val tutorId: String = intent.getStringExtra("tutorId") ?: "W2n8p5eYSzdNR5sOVCyAvXC6j0Q2"
        setContent {
            CalendarScreen(course, tutorId)
        }
    }
}

@Composable
fun CalendarScreen(course: Course, tutorId: String) {
    var selectedMonth by remember { mutableStateOf(LocalDate.now().monthValue) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    val daysInMonth = LocalDate.of(LocalDate.now().year, selectedMonth, 1).lengthOfMonth()
    val currentUser = FirebaseAuth.getInstance().currentUser
    val studentId = currentUser?.uid ?: "7eolTNGaYmbcnogJZejIkY1WQJI2"
    var showTimeSelection by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Select a Month", style = MaterialTheme.typography.headlineMedium)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            Button(onClick = { if (selectedMonth > 1) selectedMonth-- }) {
                Text("Previous")
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text("Month: $selectedMonth")
            Spacer(modifier = Modifier.width(16.dp))
            Button(onClick = { if (selectedMonth < 12) selectedMonth++ }) {
                Text("Next")
            }
        }

        Text("Selected Date: ${selectedDate.dayOfMonth}/${selectedDate.monthValue}", style = MaterialTheme.typography.bodyLarge)
        LazyVerticalGrid(columns = GridCells.Fixed(7), modifier = Modifier.padding(8.dp)) {
            items(daysInMonth) { day ->
                val date = LocalDate.of(LocalDate.now().year, selectedMonth, day + 1)
                Text(
                    text = date.format(DateTimeFormatter.ofPattern("d")),
                    modifier = Modifier
                        .padding(8.dp)
                        .clickable {
                            selectedDate = date
                            showTimeSelection = true
                        }
                )
            }
        }

        if (showTimeSelection) {
            openTimeSelection(studentId, tutorId, selectedDate, course, onClose = {
                showTimeSelection = false
            })
        }
    }
}

fun generateAvailableTimes(timeBlocks: List<TimeBlock>): List<Int> {
    val availableTimes = mutableListOf<Int>()
    timeBlocks.forEach { block ->
        var time = block.timeFrom ?: 0
        while (time < (block.timeTo ?: 0)) {
            availableTimes.add(time)
            time += 100 // Increment by 1-hour intervals (1400 -> 1500 -> 1600)
        }
    }
    return availableTimes
}

fun formatTime(time: Int): String {
    val hour = time / 100
    val minute = time % 100
    val period = if (hour >= 12) "PM" else "AM"
    val formattedHour = if (hour > 12) hour - 12 else hour
    return String.format("%d:%02d %s", formattedHour, minute, period)
}

@Composable
fun openTimeSelection(studentId: String, tutorId: String, selectedDate: LocalDate, course: Course, onClose: () -> Unit) {
    val database = FirebaseDatabase.getInstance().reference
    val context = LocalContext.current
    var selectedTimeFrom by remember { mutableStateOf<Int?>(null) }
    var selectedTimeTo by remember { mutableStateOf<Int?>(null) }
    var availableTimePairs by remember { mutableStateOf(listOf<Pair<Int, List<Int>>>() ) }
    var availableTimeBlocks by remember { mutableStateOf(listOf<TimeBlock>()) }
    var tutorSchedule by remember { mutableStateOf(listOf<TimeBlock>()) }
    var studentSchedule by remember { mutableStateOf(listOf<TimeBlock>()) }

    // Refresh dropdowns when the selected month changes
    var refreshKey by remember { mutableStateOf(selectedDate.monthValue) }

    // Fetch tutor's availability and schedules on month/date change
    LaunchedEffect(tutorId, studentId, selectedDate, refreshKey) {
        selectedTimeFrom = null
        selectedTimeTo = null
        availableTimePairs = emptyList()

        // Fetch tutor's available time blocks
        database.child("Users").child(tutorId).child("availableTimeBlocks").get()
            .addOnSuccessListener { snapshot ->
                val timeBlocks = snapshot.children.mapNotNull { it.getValue(TimeBlock::class.java) }
                    .filter { it.getDate().isEqual(selectedDate) }

                availableTimeBlocks = timeBlocks

                // Fetch tutor's schedule (existing booked sessions)
                database.child("Users").child(tutorId).child("schedule").get()
                    .addOnSuccessListener { scheduleSnapshot ->
                        tutorSchedule = scheduleSnapshot.children.mapNotNull {
                            it.child("timeBlock").getValue(TimeBlock::class.java)
                        }

                        // Fetch student's schedule (existing booked sessions)
                        database.child("Users").child(studentId).child("schedule").get()
                            .addOnSuccessListener { studentSnapshot ->
                                studentSchedule = studentSnapshot.children.mapNotNull {
                                    it.child("timeBlock").getValue(TimeBlock::class.java)
                                }

                                // Generate available time pairs for dropdown
                                val timePairs = mutableListOf<Pair<Int, List<Int>>>()
                                timeBlocks.forEach { block ->
                                    var time = block.timeFrom ?: 0
                                    while (time + 100 <= (block.timeTo ?: 0)) {
                                        val validEndTimes = mutableListOf<Int>()

                                        // Ensure `dateTo` does not exceed availability
                                        if (time + 100 <= block.timeTo!!) validEndTimes.add(time + 100)
                                        if (time + 200 <= block.timeTo!!) validEndTimes.add(time + 200)

                                        if (validEndTimes.isNotEmpty()) {
                                            timePairs.add(Pair(time, validEndTimes))
                                        }
                                        time += 100
                                    }
                                }
                                availableTimePairs = timePairs
                            }
                    }
            }
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Select Time Slot", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))

        if (availableTimePairs.isNotEmpty()) {
            var expandedFrom by remember { mutableStateOf(false) }
            Box(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Button(onClick = { expandedFrom = true }) {
                    Text(selectedTimeFrom?.let { formatTime(it) } ?: "Select Start Time")
                }
                DropdownMenu(expanded = expandedFrom, onDismissRequest = { expandedFrom = false }) {
                    availableTimePairs.map { it.first }.distinct().forEach { time ->
                        DropdownMenuItem(
                            text = { Text(formatTime(time)) },
                            onClick = {
                                selectedTimeFrom = time
                                selectedTimeTo = null // Reset selectedTimeTo
                                expandedFrom = false
                            }
                        )
                    }
                }
            }

            if (selectedTimeFrom != null) {
                var expandedTo by remember { mutableStateOf(false) }
                val validEndTimes = availableTimePairs.find { it.first == selectedTimeFrom }?.second ?: listOf()

                if (validEndTimes.isNotEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        Button(onClick = { expandedTo = true }) {
                            Text(selectedTimeTo?.let { formatTime(it) } ?: "Select End Time")
                        }
                        DropdownMenu(expanded = expandedTo, onDismissRequest = { expandedTo = false }) {
                            validEndTimes.forEach { time ->
                                DropdownMenuItem(
                                    text = { Text(formatTime(time)) },
                                    onClick = {
                                        selectedTimeTo = time
                                        expandedTo = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        } else {
            Text("No available slots for this date", style = MaterialTheme.typography.bodyMedium)
        }

        Button(onClick = {
            if (selectedTimeFrom != null && selectedTimeTo != null) {
                val timeBlock = TimeBlock(
                    timeFrom = selectedTimeFrom, timeTo = selectedTimeTo,
                    month = selectedDate.monthValue, week = ((selectedDate.dayOfMonth - 1) / 7 + 1), day = selectedDate.dayOfWeek.value
                )

                // Check for conflicts before saving session
                if (tutorSchedule.any { it.conflictsWith(timeBlock.timeFrom!!, timeBlock.timeTo!!) } ||
                    studentSchedule.any { it.conflictsWith(timeBlock.timeFrom!!, timeBlock.timeTo!!) }) {
                    Toast.makeText(context, "Selected time conflicts with an existing session", Toast.LENGTH_SHORT).show()
                    return@Button
                }

                val sessionKey = database.child("Sessions").push().key ?: return@Button

                val sessionMap = mapOf(
                    "course" to mapOf(
                        "gradeLevel" to (course.gradeLevel ?: ""),
                        "subject" to (course.subject ?: "")
                    ),
                    "student" to mapOf(
                        "id" to studentId
                    ),
                    "tutor" to mapOf(
                        "id" to tutorId
                    ),
                    "timeBlock" to mapOf(
                        "timeFrom" to timeBlock.timeFrom,
                        "timeTo" to timeBlock.timeTo,
                        "month" to timeBlock.month,
                        "week" to timeBlock.week,
                        "day" to timeBlock.day
                    )
                )

                val sessionPath = "Sessions/$sessionKey"
                val studentScheduleRef = database.child("Users").child(studentId).child("schedule")
                val tutorScheduleRef = database.child("Users").child(tutorId).child("schedule")

                val updates = mapOf(sessionPath to sessionMap)

                database.updateChildren(updates).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        studentScheduleRef.push().setValue(sessionMap)
                        tutorScheduleRef.push().setValue(sessionMap)
                        Toast.makeText(context, "Session scheduled successfully", Toast.LENGTH_SHORT).show()
                        onClose()
                    } else {
                        Toast.makeText(context, "Failed to schedule session: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }) {
            Text("Confirm Time")
        }
    }
}

// Function to check if a time block conflicts with existing bookings
fun TimeBlock.conflictsWith(timeFrom: Int, timeTo: Int): Boolean {
    return this.timeFrom!! < timeTo && this.timeTo!! > timeFrom
}

/*
Alternative code for checking conflicts at dropdown menu, instead of
during confirm. (Cleaner UI at the cost of efficiency/performance)
 */
//@Composable
//fun openTimeSelection(studentId: String, tutorId: String, selectedDate: LocalDate, course: Course, onClose: () -> Unit) {
//    val database = FirebaseDatabase.getInstance().reference
//    val context = LocalContext.current
//    var selectedTimeFrom by remember { mutableStateOf<Int?>(null) }
//    var selectedTimeTo by remember { mutableStateOf<Int?>(null) }
//    var availableTimePairs by remember { mutableStateOf(listOf<Pair<Int, List<Int>>>() ) }
//    var availableTimeBlocks by remember { mutableStateOf(listOf<TimeBlock>()) }
//    var tutorSchedule by remember { mutableStateOf(listOf<TimeBlock>()) }
//    var studentSchedule by remember { mutableStateOf(listOf<TimeBlock>()) }
//
//    // Fetch Tutor's & Student's Schedules
//    LaunchedEffect(tutorId, studentId, selectedDate) {
//        selectedTimeFrom = null
//        selectedTimeTo = null
//
//        database.child("Users").child(tutorId).child("availableTimeBlocks").get()
//            .addOnSuccessListener { snapshot ->
//                val timeBlocks = snapshot.children.mapNotNull { it.getValue(TimeBlock::class.java) }
//                    .filter { it.getDate().isEqual(selectedDate) }
//
//                availableTimeBlocks = timeBlocks
//
//                // Fetch scheduled sessions for the tutor
//                database.child("Users").child(tutorId).child("schedule").get()
//                    .addOnSuccessListener { scheduleSnapshot ->
//                        val scheduledBlocks = scheduleSnapshot.children.mapNotNull { sessionSnapshot ->
//                            val timeBlockMap = sessionSnapshot.child("timeBlock").value as? Map<String, Any>
//                            timeBlockMap?.let {
//                                TimeBlock(
//                                    timeFrom = (it["timeFrom"] as Long).toInt(),
//                                    timeTo = (it["timeTo"] as Long).toInt(),
//                                    month = (it["month"] as Long).toInt(),
//                                    week = (it["week"] as Long).toInt(),
//                                    day = (it["day"] as Long).toInt()
//                                )
//                            }
//                        }
//                        tutorSchedule = scheduledBlocks
//
//                        // Fetch scheduled sessions for the student
//                        database.child("Users").child(studentId).child("schedule").get()
//                            .addOnSuccessListener { studentSnapshot ->
//                                val studentBlocks = studentSnapshot.children.mapNotNull { sessionSnapshot ->
//                                    val timeBlockMap = sessionSnapshot.child("timeBlock").value as? Map<String, Any>
//                                    timeBlockMap?.let {
//                                        TimeBlock(
//                                            timeFrom = (it["timeFrom"] as Long).toInt(),
//                                            timeTo = (it["timeTo"] as Long).toInt(),
//                                            month = (it["month"] as Long).toInt(),
//                                            week = (it["week"] as Long).toInt(),
//                                            day = (it["day"] as Long).toInt()
//                                        )
//                                    }
//                                }
//                                studentSchedule = studentBlocks
//
//                                // Generate valid time pairs considering both availability & existing bookings
//                                val timePairs = mutableListOf<Pair<Int, List<Int>>>()
//                                timeBlocks.forEach { block ->
//                                    var time = block.timeFrom ?: 0
//                                    while (time + 100 <= (block.timeTo ?: 0)) {
//                                        val validEndTimes = mutableListOf<Int>()
//
//                                        if (time + 100 <= block.timeTo!! &&
//                                            tutorSchedule.none { it.conflictsWith(time, time + 100) } &&
//                                            studentSchedule.none { it.conflictsWith(time, time + 100) }
//                                        ) {
//                                            validEndTimes.add(time + 100)
//                                        }
//                                        if (time + 200 <= block.timeTo!! &&
//                                            tutorSchedule.none { it.conflictsWith(time, time + 200) } &&
//                                            studentSchedule.none { it.conflictsWith(time, time + 200) }
//                                        ) {
//                                            validEndTimes.add(time + 200)
//                                        }
//
//                                        if (validEndTimes.isNotEmpty()) {
//                                            timePairs.add(Pair(time, validEndTimes))
//                                        }
//                                        time += 100
//                                    }
//                                }
//                                availableTimePairs = timePairs
//                            }
//                    }
//            }
//    }
//
//    Column(
//        modifier = Modifier.fillMaxSize(),
//        horizontalAlignment = Alignment.CenterHorizontally
//    ) {
//        Text("Select Time Slot", style = MaterialTheme.typography.headlineMedium)
//        Spacer(modifier = Modifier.height(16.dp))
//
//        if (availableTimePairs.isNotEmpty()) {
//            var expandedFrom by remember { mutableStateOf(false) }
//            Box(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
//                Button(onClick = { expandedFrom = true }) {
//                    Text(selectedTimeFrom?.let { formatTime(it) } ?: "Select Start Time")
//                }
//                DropdownMenu(expanded = expandedFrom, onDismissRequest = { expandedFrom = false }) {
//                    availableTimePairs.map { it.first }.distinct().forEach { time ->
//                        DropdownMenuItem(
//                            text = { Text(formatTime(time)) },
//                            onClick = {
//                                selectedTimeFrom = time
//                                selectedTimeTo = null // Reset selectedTimeTo
//                                expandedFrom = false
//                            }
//                        )
//                    }
//                }
//            }
//
//            if (selectedTimeFrom != null) {
//                var expandedTo by remember { mutableStateOf(false) }
//                val validEndTimes = availableTimePairs.find { it.first == selectedTimeFrom }?.second ?: listOf()
//
//                if (validEndTimes.isNotEmpty()) {
//                    Box(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
//                        Button(onClick = { expandedTo = true }) {
//                            Text(selectedTimeTo?.let { formatTime(it) } ?: "Select End Time")
//                        }
//                        DropdownMenu(expanded = expandedTo, onDismissRequest = { expandedTo = false }) {
//                            validEndTimes.forEach { time ->
//                                DropdownMenuItem(
//                                    text = { Text(formatTime(time)) },
//                                    onClick = {
//                                        selectedTimeTo = time
//                                        expandedTo = false
//                                    }
//                                )
//                            }
//                        }
//                    }
//                }
//            }
//        } else {
//            Text("No available slots for this date", style = MaterialTheme.typography.bodyMedium)
//        }
//
//        Button(onClick = {
//            if (selectedTimeFrom != null && selectedTimeTo != null) {
//                val timeBlock = TimeBlock(
//                    timeFrom = selectedTimeFrom, timeTo = selectedTimeTo,
//                    month = selectedDate.monthValue, week = ((selectedDate.dayOfMonth - 1) / 7 + 1), day = selectedDate.dayOfWeek.value
//                )
//
//                if (tutorSchedule.any { it.conflictsWith(timeBlock.timeFrom!!, timeBlock.timeTo!!) } ||
//                    studentSchedule.any { it.conflictsWith(timeBlock.timeFrom!!, timeBlock.timeTo!!) }) {
//                    Toast.makeText(context, "Selected time conflicts with an existing session", Toast.LENGTH_SHORT).show()
//                    return@Button
//                }
//
//                val sessionKey = database.child("Sessions").push().key ?: return@Button
//
//                val sessionMap = mapOf(
//                    "course" to mapOf(
//                        "gradeLevel" to (course.gradeLevel ?: ""),
//                        "subject" to (course.subject ?: "")
//                    ),
//                    "student" to mapOf(
//                        "id" to studentId
//                    ),
//                    "tutor" to mapOf(
//                        "id" to tutorId
//                    ),
//                    "timeBlock" to mapOf(
//                        "timeFrom" to timeBlock.timeFrom,
//                        "timeTo" to timeBlock.timeTo,
//                        "month" to timeBlock.month,
//                        "week" to timeBlock.week,
//                        "day" to timeBlock.day
//                    )
//                )
//
//                val sessionPath = "Sessions/$sessionKey"
//                val studentScheduleRef = database.child("Users").child(studentId).child("schedule")
//                val tutorScheduleRef = database.child("Users").child(tutorId).child("schedule")
//
//                val updates = mapOf(sessionPath to sessionMap)
//
//                database.updateChildren(updates).addOnCompleteListener { task ->
//                    if (task.isSuccessful) {
//                        studentScheduleRef.push().setValue(sessionMap)
//                        tutorScheduleRef.push().setValue(sessionMap)
//                        Toast.makeText(context, "Session scheduled successfully", Toast.LENGTH_SHORT).show()
//                        onClose()
//                    } else {
//                        Toast.makeText(context, "Failed to schedule session: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
//                    }
//                }
//            }
//        }) {
//            Text("Confirm Time")
//        }
//    }
//}
//
//// Function to check if a time block conflicts with existing bookings
//fun TimeBlock.conflictsWith(timeFrom: Int, timeTo: Int): Boolean {
//    return this.timeFrom!! < timeTo && this.timeTo!! > timeFrom
//}