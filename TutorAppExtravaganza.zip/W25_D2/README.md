# W25_D2
i am Fred